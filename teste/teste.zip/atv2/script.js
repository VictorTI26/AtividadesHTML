var pulaLinha = function(){
    document.write("<br>" + "<hr>" + "<br>");
     };
    
var mostra = function(frase){
     document.write(frase);
     pulaLinha();
     };

var calculaIMC = function(){
    return pesoDoUsuario/(alturaDoUsuario^2);
};
    var nome = prompt ("Digite seu nome: ");
    var alturaDoUsuario = parseFloat(prompt("Bom dia "+nome+" Qual é sua altura? "));
    var pesoDoUsuario = parseFloat(prompt("Qual é seu peso? "));
    var imcDoUsuario = calculaIMC(alturaDoUsuario, pesoDoUsuario);
    mostra("O seu imc é " + Math.round(imcDoUsuario));
